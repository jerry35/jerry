import sys
import os
import urllib
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import logging
from operator import itemgetter

def show_tags():
  tag_handle = int(sys.argv[1])
  xbmcplugin.setContent(tag_handle, 'tags')

  for tag in tags:
    iconPath = os.path.join(home, 'logos', tag['icon'])
    li = xbmcgui.ListItem(tag['name'], iconImage=iconPath)
    url = sys.argv[0] + '?tag=' + str(tag['id'])
    xbmcplugin.addDirectoryItem(handle=tag_handle, url=url, listitem=li, isFolder=True)

  xbmcplugin.endOfDirectory(tag_handle)


def show_streams(tag):
  stream_handle = int(sys.argv[1])
  xbmcplugin.setContent(stream_handle, 'streams')
  logging.warning('TAG show_streams!!!! %s', tag)
  for stream in streams[str(tag)]:
    logging.debug('STREAM HERE!!! %s', stream['name'])
    iconPath = os.path.join(home, 'logos', stream['icon'])
    li = xbmcgui.ListItem(stream['name'], iconImage=iconPath)
    xbmcplugin.addDirectoryItem(handle=stream_handle, url=stream['url'], listitem=li)

  xbmcplugin.endOfDirectory(stream_handle)


def get_params():
  """
  Retrieves the current existing parameters from XBMC.
  """
  param = []
  paramstring = sys.argv[2]
  if len(paramstring) >= 2:
    params = sys.argv[2]
    cleanedparams = params.replace('?', '')
    if params[len(params) - 1] == '/':
      params = params[0:len(params) - 2]
    pairsofparams = cleanedparams.split('&')
    param = {}
    for i in range(len(pairsofparams)):
      splitparams = {}
      splitparams = pairsofparams[i].split('=')
      if (len(splitparams)) == 2:
        param[splitparams[0]] = splitparams[1]
  return param


def lower_getter(field):
  def _getter(obj):
    return obj[field].lower()

  return _getter


addon = xbmcaddon.Addon()
home = xbmc.translatePath(addon.getAddonInfo('path'))

tags = [
  {
    'name': 'Live TV',
    'id': 'LiveTV',
    'icon': 'livetv.png'
  }, {
    'name': 'Movies',
    'id': 'Movies',
    'icon': 'movies.png'
  }
]


LiveTV = [{
  'name': 'ZING',
  'url': 'http://183.88.212.205:8010/play/a01r',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Africa TVC',
  'url': 'rtmp://77.92.76.135:1935/tvce/livestream',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Inspiration',
  'url': 'http://46.249.60.214:8666/play/a03y',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'True Ent +1',
  'url': 'http://46.249.60.214:8666/play/a01l',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Channel AKA',
  'url': 'http://46.249.60.214:8666/play/a00l',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'Forces TV',
  'url': 'http://46.249.60.214:8666/play/a04o',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'SONY SAB',
  'url': 'http://46.249.60.214:8666/play/a005',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CBS Action',
  'url': 'http://46.249.60.214:8666/play/a02a',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'cartoon',
  'url': 'http://46.249.60.214:8666/play/a00t',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'true',
  'url': 'http://46.249.60.214:8666/play/a00t',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'bbc',
  'url': 'http://46.249.60.214:8666/play/a046',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'pime tv',
  'url': 'http://46.249.60.214:8666/play/a02y',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'cnbc',
  'url': 'http://46.249.60.214:8666/play/a02h',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'C',
  'url': 'http://46.249.60.214:8666/play/a04d',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'BLAZE',
  'url': 'http://46.249.60.214:8666/play/a03x',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CAPITAL TV',
  'url': 'http://46.249.60.214:8666/play/a013',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'HOROR',
  'url': 'http://46.249.60.214:8666/play/a022',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'INDIA',
  'url': 'http://46.249.60.214:8666/play/a021',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'TRUE MOVIES',
  'url': 'http://46.249.60.214:8666/play/a00f',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CARTOON 2',
  'url': 'http://46.249.60.214:8666/play/a01g',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'COLORS',
  'url': 'http://46.249.60.214:8666/play/a00x',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'HOROR PLUS 1',
  'url': 'http://46.249.60.214:8666/play/a027',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'BRIT ASIA TV',
  'url': 'http://46.249.60.214:8666/play/a01z',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'HUM',
  'url': 'http://46.249.60.214:8666/play/a01r',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CBS REALITY',
  'url': 'http://46.249.60.214:8666/play/a01u',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CARTOON 3',
  'url': 'http://46.249.60.214:8666/play/a01j',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ROK',
  'url': 'http://46.249.60.214:8666/play/a02w',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'POP',
  'url': 'http://46.249.60.214:8666/play/a00i',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'PTC PUNJABI',
  'url': 'http://46.249.60.214:8666/play/a01b',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'PTC PUNJABI',
  'url': 'http://46.249.60.214:8666/play/a01b',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MOVIES',
  'url': 'http://46.249.60.214:8666/play/a03b',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'NOLLYWOOD',
  'url': 'http://46.249.60.214:8666/play/a033',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'B4U MUSIC',
  'url': 'http://46.249.60.214:8666/play/a02o',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'b92 azivo',
  'url': 'http://185.152.64.13:1935/livelowedge2/_definst_/b92.stream/chunklist_w1951741565.m3u8',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'MITV',
  'url': 'http://183.88.212.205:8010/play/a016',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'ASIAN MOVIES',
  'url': 'http://183.88.212.205:8010/play/a01j',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'SUN TV',
  'url': 'http://183.88.212.205:8010/play/a00o',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'FYI',
  'url': 'http://183.88.212.205:8010/play/a00k',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'CARTOON NETWORK',
  'url': 'http://183.88.212.205:8010/play/a01b',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'STAR CHINESE MOVIES',
  'url': 'http://183.88.212.205:8010/play/a02e',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'WORLD DRAMA',
  'url': 'http://183.88.212.205:8010/play/a01x',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'FX',
  'url': 'http://183.88.212.205:8010/play/a023',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'FOX FAMILY MOVIES',
  'url': 'http://183.88.212.205:8010/play/a01m',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'HBO HD',
  'url': 'http://183.88.212.205:8010/play/a00u',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'NAT GEO MUSIC',
  'url': 'http://183.88.212.205:8010/play/a01q',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk Film4',
  'url': 'http://195.189.203.18:8080/play/a01c',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk 4Music',
  'url': 'http://195.189.203.18:8080/play/a01f',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk Channel 4',
  'url': 'http://195.189.203.18:8080/play/a01b',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk Film4 +1',
  'url': 'http://195.189.203.18:8080/play/a01d',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk More4 +1',
  'url': 'http://195.189.203.18:8080/play/a01g',
  'icon': 'Vevo Tv.png',
  'disabled': False
  }, {
  'name': 'uk ,c4 l',
  'url': 'http://195.189.203.18:8080/play/a01e',
  'icon': 'Vevo Tv.png',
  'disabled': False
}, {
  'name': 'National Geographic',
  'url': '',
  'icon': 'National Geographic.png',
  'disabled': True
}, {
  'name': 'Food Network',
  'url': '',
  'icon': 'Food Network.png',
  'disabled': True
}, {
  'name': 'FX',
  'url': '',
  'icon': 'FX.png',
  'disabled': True
}]


Movies = [{
  'name': 'The King',
  'url': 'https://onedrive.live.com/download.aspx?resid=9019C8D6D3F2A237!516&authkey=!ADXBQuKDqYvTXsY&ithint=file%2cmkv',
  'icon': 'Despicable Me 2.png',
  'disabled': False
  }, {
  'name': 'GENEPELICULAS:Shaun el cordero [lat]',
  'url': 'https://onedrive.live.com/download.aspx?resid=9019C8D6D3F2A237!531&authkey=!ANZNU4aBv6dIeI4&ithint=video%2cmp4',
  'icon': 'Despicable Me 2.png',
  'disabled': False
  }, {
  'name': 'movie 1',
  'url': 'https://onedrive.live.com/download.aspx?resid=D7D05EA36C9AC105!226&authkey=!AF8f8HX22xDQGeg&ithint=video%2cmp4',
  'icon': 'Despicable Me 2.png',
  'disabled': False
  }, {
  'name': 'movie 2',
  'url': 'https://onedrive.live.com/download.aspx?resid=D7D05EA36C9AC105!217&authkey=!ABWBQFfi5w4LlTk&ithint=video%2cmp4',
  'icon': 'Despicable Me 2.png',
  'disabled': False
  }, {
  'name': 'movie 3',
  'url': 'https://onedrive.live.com/download.aspx?resid=8F8E52C3E63CF853!1810&authkey=!ADxysPcJZHoaTpI&ithint=file%2cmkv',
  'icon': 'Despicable Me 2.png',
  'disabled': False
}]


streams = {
  'LiveTV': sorted((i for i in LiveTV if not i.get('disabled', False)), key=lower_getter('name')),
  'Movies': sorted((i for i in Movies if not i.get('disabled', False)), key=lower_getter('name')),
  # 'LiveTV': sorted(LiveTV, key=lower_getter('name')),
  # 'Movies': sorted(Movies, key=lower_getter('name')),
}

PARAMS = get_params()
TAG = None
logging.warning('PARAMS!!!! %s', PARAMS)

try:
  TAG = PARAMS['tag']
except:
  pass

logging.warning('ARGS!!!! sys.argv %s', sys.argv)

if TAG == None:
  show_tags()
else:
  show_streams(TAG)
